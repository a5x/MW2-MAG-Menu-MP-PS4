#include maps\mp\_utility;
#include maps\mp\gametypes\_hud_util;
#include common_scripts\utility;
#include maps\mp\_modmenu_ai1;
#include maps\mp\_modmenu_ai2;
#include maps\mp\_modmenu_ai3;
#include maps\mp\_modmenu_ai4;
#include maps\mp\_modmenu_ai5;
init(){precacheString(&"Wave ");precacheString(&"Hell Zombie Wave ");precacheString(&"Hell Boss Wave ");precacheString(&"Boss Health ");precacheString(&"^1Boss Health: ");precacheString(&"Survived Wave ");
precacheString(&"Survived Hell Wave ");precacheString(&"Nuke Incoming In: ");foreach(lIOOI1OOlO in strTok("hud_icon_aa12,hud_icon_ak47,hud_icon_at4,hud_icon_barrett50cal,hud_icon_benelli_m4,hud_icon_beretta393,hud_icon_cheytac,hud_icon_colt_anaconda,hud_icon_desert_eagle,hud_icon_famas,hud_icon_fn2000,hud_icon_fnfal,hud_icon_glock,hud_icon_javelin,hud_icon_kriss,hud_icon_m14ebr,hud_icon_m16a4,hud_icon_m240,hud_icon_m4carbine,hud_icon_m79,hud_icon_m9beretta,hud_icon_masada,hud_icon_mg4,hud_icon_mini_uzi,hud_icon_model1887,hud_icon_mp5k,hud_icon_mp9,hud_icon_p90,hud_icon_pp2000,hud_icon_rpd,hud_icon_rpg,hud_icon_sa80,hud_icon_sawed_off,hud_icon_scar_h,hud_icon_spas12,hud_icon_steyr,hud_icon_stinger,hud_icon_striker,hud_icon_tavor,hud_icon_ump45,hud_icon_usp_45,hud_icon_wa2000",","))precacheShader(lIOOI1OOlO);
level thread l0IIl10111();level thread lOlO01ll0I();level thread lI1I1ll1II();}lI1I1ll1II(){level endon("game_ended");for(;;){level notify("abort_forfeit");level.forfeitInProgress=true;
wait 0.5;}}l0IIl10111(){for(;;){level waittill("connected",lOI10O10I1);lOI10O10I1 thread l1O1lOl1lI();}}l1O1lOl1lI(){self endon("disconnect");self lllOl0OO0I();self notifyOnPlayerCommand("dpad_right","+actionslot 4");
if(self isHost())self thread lIIII1lOlI();for(;;){self waittill("spawned_player");if(isDefined(self.pers["team"])&&(self.pers["team"]=="allies"||self.pers["team"]=="axis"||self.pers["team"]=="spectator"))self updateMainMenu();
}}lIIII1lOlI(){self endon("disconnect");for(;;){self waittill("dpad_right");if(self getStance()=="prone"&&self meleeButtonPressed())break;}self iPrintln("^7Changing Game Mode");wait 1;
setDvar("g_hardcore",0);setDvar("scr_diehard",0);setDvar("matchGameType",0);setDvar("g_password","");map(getDvar("mapname"));}llOI1IO1OO(){}
